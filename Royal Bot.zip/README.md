# Suscribe to KP 18 Gamer
- [Subscribe](https://www.youtube.com/channel/UCo2iuPS4FZ8V6H_ct2F8-2A/featured)
# Discord-Bot
200+ commands free open source code of discord bot

## This bot was made Atreya YT#0513, do not remove credits or you will have copyright issues.
### Make sure to join The servers below:
- [Recluse Community](https://discord.gg/gU7XAxTpX5)

#### Star the repo and fork it, Ty
###### Things You should not do
- Dont remove credits
- Dont say u created it when u didnt
- dont copy paste or u will never learn
##### Things you should to do:
- Suscribe to  KP 18 AKA Atreya
- star this repo
- fork this repo
- follow me
- make videos on my projects
- Gift me nitro for more code
- join recluse community


##### Modification 
- Add you token in config and .env
- Add you ID in `owner.json`
- Goto `server.js` number 163 and add your channel ID
- run it by `node server.js` 


![image](https://user-images.githubusercontent.com/74746579/115984077-e0493800-a5c4-11eb-93f6-6c8c5bd8728b.png)
- Go secrets[Environment Variable] and add TOKEN and paste token there if you are in repl.it or put  add token in .env file

- Run in repl.it
- [Click Here](https://replit.com/@GamingDiwas/Discord-bot#README.md)


Please Subscribe to my channel and for help join my server.
